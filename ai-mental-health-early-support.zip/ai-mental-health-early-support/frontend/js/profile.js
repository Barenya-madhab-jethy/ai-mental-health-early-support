// --- PROFILE.JS ---
// Loads + updates user profile

import { API_BASE, authHeaders } from "./api.js";

document.addEventListener("DOMContentLoaded", loadProfile);

async function loadProfile() {
    const res = await fetch(`${API_BASE}/auth/me`, {
        headers: authHeaders()
    });

    const user = await res.json();

    document.getElementById("pName").value = user.name;
    document.getElementById("pEmail").value = user.email;

    document.getElementById("saveProfile").onclick = () => updateProfile(user.id);
}

async function updateProfile(userId) {
    const name = document.getElementById("pName").value;

    await fetch(`${API_BASE}/auth/update/${userId}`, {
        method: "PUT",
        headers: authHeaders(),
        body: JSON.stringify({ name })
    });

    alert("Profile updated!");
}