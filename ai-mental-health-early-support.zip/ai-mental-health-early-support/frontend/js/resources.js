// --- RESOURCES.JS ---
// Loads mental health resources from backend

import { API_BASE, authHeaders } from "./api.js";

document.addEventListener("DOMContentLoaded", loadResources);

async function loadResources() {
    const res = await fetch(`${API_BASE}/resources`, {
        headers: authHeaders()
    });

    const data = await res.json();

    const box = document.getElementById("resourceList");
    box.innerHTML = "";

    data.forEach(r => {
        const card = document.createElement("div");
        card.className = "resource-card";

        card.innerHTML = `
            <h3>${r.title}</h3>
            <p>${r.description}</p>
            <a href="${r.url}" target="_blank">Open Resource</a>
        `;

        box.appendChild(card);
    });
}