// --- JOURNAL.JS ---
// Save journal entries + get AI emotional support

import { askGemini, API_BASE, authHeaders } from "./api.js";

document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("saveJournal").addEventListener("click", saveJournal);
    loadEntries();
});

async function saveJournal() {
    const text = document.getElementById("journalText").value.trim();
    if (!text) return alert("Write something first.");

    // Store in backend
    await fetch(`${API_BASE}/journal`, {
        method: "POST",
        headers: authHeaders(),
        body: JSON.stringify({ text })
    });

    // Ask AI for reflection
    const aiReply = await askGemini(
        "User wrote this journal entry: " + text +
        "\nProvide emotional support in 2-3 sentences."
    );

    document.getElementById("aiResponse").innerText = aiReply;

    loadEntries();
}

async function loadEntries() {
    const res = await fetch(`${API_BASE}/journal`, {
        headers: authHeaders()
    });

    const entries = await res.json();

    const container = document.getElementById("journalList");
    container.innerHTML = "";

    entries.reverse().forEach(e => {
        const div = document.createElement("div");
        div.className = "journal-entry";
        div.innerHTML = `<p>${e.text}</p><small>${e.created_at}</small>`;
        container.appendChild(div);
    });
}