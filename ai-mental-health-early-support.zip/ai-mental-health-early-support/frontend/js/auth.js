// --- AUTH.JS ---
// Handles login, signup, token storage, logout

const API_BASE = "http://localhost:8000";

document.addEventListener("DOMContentLoaded", () => {
    const loginForm = document.getElementById("loginForm");
    const signupForm = document.getElementById("signupForm");
    const showSignup = document.getElementById("showSignup");
    const showLogin = document.getElementById("showLogin");
    const loginSection = document.getElementById("loginSection");
    const signupSection = document.getElementById("signupSection");
    const anonymousLogin = document.getElementById("anonymousLogin");

    if (loginForm) {
        loginForm.addEventListener("submit", (e) => {
            e.preventDefault();
            loginUser();
        });
    }

    if (signupForm) {
        signupForm.addEventListener("submit", (e) => {
            e.preventDefault();
            signupUser();
        });
    }

    if (showSignup) {
        showSignup.addEventListener("click", (e) => {
            e.preventDefault();
            loginSection.style.display = "none";
            signupSection.style.display = "block";
        });
    }

    if (showLogin) {
        showLogin.addEventListener("click", (e) => {
            e.preventDefault();
            signupSection.style.display = "none";
            loginSection.style.display = "block";
        });
    }

    if (anonymousLogin) {
        anonymousLogin.addEventListener("click", (e) => {
            e.preventDefault();
            anonymousLoginUser();
        });
    }
});

async function loginUser() {
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;

    try {
        const res = await fetch(`${API_BASE}/auth/login`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email, password })
        });

        const data = await res.json();

        if (res.ok) {
            localStorage.setItem("token", data.access_token);
            window.location.href = "dashboard.html";
        } else {
            alert(data.detail || "Login failed");
        }
    } catch (error) {
        console.error("Login error:", error);
        alert("Login failed. Please try again.");
    }
}

async function signupUser() {
    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("emailSignup").value.trim();
    const password = document.getElementById("passwordSignup").value;

    try {
        const res = await fetch(`${API_BASE}/auth/signup`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, email, password })
        });

        const data = await res.json();

        if (res.ok) {
            alert("Signup successful! Please login.");
            signupSection.style.display = "none";
            loginSection.style.display = "block";
        } else {
            alert(data.detail || "Signup failed");
        }
    } catch (error) {
        console.error("Signup error:", error);
        alert("Signup failed. Please try again.");
    }
}

async function anonymousLoginUser() {
    try {
        const res = await fetch(`${API_BASE}/auth/anonymous`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({})
        });

        const data = await res.json();

        if (res.ok) {
            localStorage.setItem("token", data.access_token);
            window.location.href = "dashboard.html";
        } else {
            alert(data.detail || "Anonymous login failed");
        }
    } catch (error) {
        console.error("Anonymous login error:", error);
        alert("Anonymous login failed. Please try again.");
    }
}