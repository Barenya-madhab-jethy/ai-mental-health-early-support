// --- DASHBOARD.JS ---
// Loads greeting + handles dashboard interactions

import { askGemini, API_BASE, authHeaders } from "./api.js";

let mediaRecorder;
let chunks = [];

document.addEventListener("DOMContentLoaded", async() => {
    const greetBox = document.getElementById("greetBox");
    const responseBox = document.getElementById("responseBox");

    // Check if user is logged in
    const token = localStorage.getItem("token");
    let isLoggedIn = !!token;

    // Load initial greeting
    if (isLoggedIn) {
        try {
            const greeting = await askGemini(
                "Give a short supportive mental health message in one sentence."
            );
            greetBox.innerText = greeting;
        } catch (error) {
            console.error("Error loading greeting:", error);
            greetBox.innerText = "Welcome! Please ensure you are logged in.";
            isLoggedIn = false; // Treat as not logged in if API fails
        }
    } else {
        greetBox.innerText = "Please log in to access AI features.";
    }

    // Function to append response to responseBox
    function appendResponse(response, type) {
        const p = document.createElement("p");
        p.innerHTML = `<strong>${type}:</strong> ${response}`;
        responseBox.appendChild(p);
    }

    // Mood Analyzer
    document.getElementById("analyzeBtn").addEventListener("click", async() => {
        if (!isLoggedIn) {
            alert("Please log in to use AI features.");
            return;
        }
        const moodText = document.getElementById("moodText").value.trim();
        if (!moodText) {
            alert("Please enter your mood description.");
            return;
        }

        try {
            const analysis = await askGemini(`Analyze this mood: "${moodText}". Provide supportive insights.`);
            document.getElementById("analysisResult").innerText = analysis;
            appendResponse(analysis, "Mood Analysis");
        } catch (error) {
            console.error("Error analyzing mood:", error);
            document.getElementById("analysisResult").innerText = "Error analyzing mood. Please check your login.";
        }
    });

    // AI Advice
    document.getElementById("adviceBtn").addEventListener("click", async() => {
        if (!isLoggedIn) {
            alert("Please log in to use AI features.");
            return;
        }
        const adviceInput = document.getElementById("adviceInput").value.trim();
        if (!adviceInput) {
            alert("Please enter your question.");
            return;
        }
        try {
            const advice = await askGemini(adviceInput);
            document.getElementById("adviceResult").innerText = advice;
            appendResponse(advice, "AI Advice");
        } catch (error) {
            console.error("Error getting advice:", error);
            document.getElementById("adviceResult").innerText = "Error getting advice. Please check your login.";
        }
    });

    // Voice Note
    document.getElementById("recordBtn").addEventListener("click", () => {
        if (!isLoggedIn) {
            alert("Please log in to use AI features.");
            return;
        }
        startRecording();
    });
    document.getElementById("stopBtn").addEventListener("click", stopRecording);
});

async function startRecording() {
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        mediaRecorder = new MediaRecorder(stream);

        mediaRecorder.ondataavailable = e => chunks.push(e.data);
        mediaRecorder.onstop = async() => {
            const blob = new Blob(chunks, { type: "audio/webm" });
            chunks = [];

            const formData = new FormData();
            formData.append("file", blob, "voice.webm");

            try {
                const res = await fetch(`${API_BASE}/voice`, {
                    method: "POST",
                    headers: { Authorization: authHeaders().Authorization },
                    body: formData
                });
                if (res.ok) {
                    const aiMsg = await askGemini("User recorded an emotional voice note. Provide a comforting, short reply.");
                    document.getElementById("voiceAI").innerText = aiMsg;
                    appendResponse(aiMsg, "Voice Note Response");
                } else {
                    throw new Error("Upload failed");
                }
            } catch (error) {
                console.error("Error uploading voice note:", error);
                document.getElementById("voiceAI").innerText = "Error processing voice note.";
            }

            document.getElementById("recordBtn").style.display = "inline";
            document.getElementById("stopBtn").style.display = "none";
            document.getElementById("voiceStatus").innerText = "Recording stopped.";
        };

        mediaRecorder.start();

        document.getElementById("recordBtn").style.display = "none";
        document.getElementById("stopBtn").style.display = "inline";
        document.getElementById("voiceStatus").innerText = "Recording...";
    } catch (error) {
        console.error("Error starting recording:", error);
        alert("Could not access microphone.");
    }
}

async function stopRecording() {
    if (!mediaRecorder) return;

    mediaRecorder.stop();
}