// --- VOICE.JS ---
// Records voice notes + sends to backend for AI analysis

import { API_BASE, authHeaders, askGemini } from "./api.js";

let mediaRecorder;
let chunks = [];

document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("recordBtn").onclick = startRecording;
    document.getElementById("stopBtn").onclick = stopRecording;
});

async function startRecording() {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    mediaRecorder = new MediaRecorder(stream);

    mediaRecorder.ondataavailable = e => chunks.push(e.data);
    mediaRecorder.start();
}

async function stopRecording() {
    mediaRecorder.stop();

    mediaRecorder.onstop = async() => {
        const blob = new Blob(chunks, { type: "audio/webm" });
        chunks = [];

        const formData = new FormData();
        formData.append("file", blob, "voice.webm");

        await fetch(`${API_BASE}/voice`, {
            method: "POST",
            headers: { Authorization: "Bearer " + localStorage.getItem("token") },
            body: formData
        });

        const aiMsg = await askGemini(
            "User recorded an emotional voice note. Provide a comforting, short reply."
        );

        document.getElementById("voiceAI").innerText = aiMsg;
    };
}