// --- API.JS ---
// Handles FastAPI communication

export async function askGemini(prompt) {
    const res = await fetch(`${API_BASE}/ai/ask`, {
        method: "POST",
        headers: authHeaders(),
        body: JSON.stringify({ prompt })
    });

    if (!res.ok) {
        throw new Error(`API error: ${res.status}`);
    }

    const data = await res.json();
    return data.response || "Sorry, I couldn't generate a response.";
}

export function authHeaders() {
    return {
        "Content-Type": "application/json",
        Authorization: "Bearer " + localStorage.getItem("token")
    };
}

export const API_BASE = "http://localhost:8000";