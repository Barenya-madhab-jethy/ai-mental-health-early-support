import os
import httpx
from ..config import GEMINI_API_KEY

BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"
# NOTE: Do not hard-code model names; change to your target model if needed
MODEL = "gemini-pro"  # adjust if your account has a different model name

def analyze_text(text: str) -> str:
    """
    Simple wrapper to call Gemini generate API and return text output.
    In production, handle errors, rate-limits, and sensitive content carefully.
    """
    if not GEMINI_API_KEY:
        raise RuntimeError("GEMINI_API_KEY not configured in environment")

    url = f"{BASE_URL}/{MODEL}:generateContent?key={GEMINI_API_KEY}"
    payload = {
        "contents": [
            {
                "parts": [
                    {
                        "text": text
                    }
                ]
            }
        ],
        "generationConfig": {
            "temperature": 0.2,
            "maxOutputTokens": 200
        }
    }
    # The Google generative API shape may differ; adjust to your SDK spec.
    try:
        with httpx.Client(timeout=20) as client:
            resp = client.post(url, json=payload)
            resp.raise_for_status()
            data = resp.json()
            # Attempt to pull the response text from known response shapes
            # This may need changing depending on API version
            try:
                # common shape: data["candidates"][0]["content"]["parts"][0]["text"]
                candidates = data.get("candidates", [])
                if candidates:
                    first = candidates[0]
                    content = first.get("content", {})
                    parts = content.get("parts", [])
                    if parts:
                        return parts[0].get("text", "No response generated")
            except Exception:
                pass
            # Last fallback: stringify entire response
            return str(data)
    except Exception as e:
        return f"API Error: {str(e)}"
