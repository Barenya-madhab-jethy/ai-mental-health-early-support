import re
from typing import Dict
from .gemini_client import ask_gemini

# -----------------------------
# Simple keyword-based sentiment scoring
# -----------------------------

NEGATIVE_WORDS = [
    "sad", "depressed", "alone", "anxious", "stress", "hopeless",
    "tired", "scared", "fear", "angry", "worthless", "empty"
]

CRISIS_WORDS = [
    "suicide", "kill myself", "end my life", "can't live", "die",
    "harm myself", "cut myself", "self harm"
]

POSITIVE_WORDS = [
    "happy", "calm", "okay", "fine", "improving", "better",
    "hope", "excited", "peaceful", "relaxed"
]

# -----------------------------
# Simple keyword-based NLP
# -----------------------------

def basic_sentiment(text: str) -> str:
    text_low = text.lower()

    neg_count = sum(1 for w in NEGATIVE_WORDS if w in text_low)
    pos_count = sum(1 for w in POSITIVE_WORDS if w in text_low)

    if neg_count > pos_count:
        return "negative"
    elif pos_count > neg_count:
        return "positive"
    return "neutral"


def crisis_detection(text: str) -> bool:
    text_low = text.lower()
    return any(kw in text_low for kw in CRISIS_WORDS)


def risk_score(text: str) -> int:
    """
    Returns an integer risk score between 0 and 100.
    """
    score = 0
    t = text.lower()

    # Add weight for crisis keywords
    if crisis_detection(t):
        score += 60

    # Add for negative words
    score += sum(5 for w in NEGATIVE_WORDS if w in t)

    # Reduce for positive words
    score -= sum(3 for w in POSITIVE_WORDS if w in t)

    # Clamp between 0 and 100
    return max(0, min(score, 100))


# -----------------------------
# Gemini AI Enhanced Emotional & Mental Health Analysis
# -----------------------------

async def ai_deep_analysis(text: str) -> Dict:
    """
    Calls Gemini to generate a structured emotional analysis.
    """

    prompt = f"""
You are an AI mental-health assistant.
Analyze the emotional state from this text and return a JSON object only.

Text:
{text}

Return JSON with:
- "emotion": dominant emotion (sadness, stress, anger, fear, hope, neutral, etc.)
- "summary": short emotional summary (1-2 sentences)
- "risk_level": low / medium / high
- "advice": short supportive advice
- "keywords": list of emotional keywords detected
"""

    gemini_response = await ask_gemini(prompt)

    # If Gemini fails, return fallback
    if not gemini_response:
        return {
            "emotion": basic_sentiment(text),
            "summary": "Unable to retrieve AI insights. Using basic analysis.",
            "risk_level": "high" if crisis_detection(text) else "medium" if risk_score(text) > 40 else "low",
            "advice": "Try expressing more of your thoughts. You are not alone.",
            "keywords": [],
        }

    # Gemini returns pure text → ensure it's valid JSON
    import json
    try:
        data = json.loads(gemini_response)
    except:
        data = {
            "emotion": basic_sentiment(text),
            "summary": "AI returned unreadable format. Basic analysis used.",
            "risk_level": "medium",
            "advice": "Try to reflect on your emotions with kindness.",
            "keywords": [],
        }

    return data


# -----------------------------
# Combined Analysis Pipeline
# -----------------------------

async def analyze_text(text: str) -> Dict:
    """
    Master function called by journal/post/voice APIs.
    Combines keyword sentiment + Gemini deep analysis.
    """

    basic = basic_sentiment(text)
    crisis = crisis_detection(text)
    risk = risk_score(text)

    ai = await ai_deep_analysis(text)

    return {
        "basic_sentiment": basic,
        "risk_score": risk,
        "crisis_detected": crisis,
        "ai_analysis": ai,
    }
