from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .db import Base, engine
from .auth import routes_auth
from .api import routes_journal, routes_voice, routes_resources, routes_posts, routes_ai

# Create DB tables (for sqlite/dev)
Base.metadata.create_all(bind=engine)

app = FastAPI(title="AI Mental Health Early-Support System")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # restrict in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(routes_auth.router, prefix="/auth", tags=["auth"])
app.include_router(routes_journal.router, prefix="/journal", tags=["journal"])
app.include_router(routes_voice.router, prefix="/voice", tags=["voice"])
app.include_router(routes_resources.router, prefix="/resources", tags=["resources"])
app.include_router(routes_posts.router, prefix="/posts", tags=["posts"])
app.include_router(routes_ai.router, prefix="/ai", tags=["ai"])

@app.get("/")
def root():
    return {"status": "ok", "service": "AI Mental Health Early-Support System"}
