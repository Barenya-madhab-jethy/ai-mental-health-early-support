import re
import random
import string
from datetime import datetime
from passlib.context import CryptContext
from fastapi.responses import JSONResponse


# -----------------------------
# Password Hashing Configuration
# -----------------------------
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


# -----------------------------
# Password Helpers
# -----------------------------
def hash_password(password: str) -> str:
    """Hash a password using bcrypt."""
    return pwd_context.hash(password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify that a plaintext password matches the stored hash."""
    return pwd_context.verify(plain_password, hashed_password)


# -----------------------------
# Email Validation
# -----------------------------
def is_valid_email(email: str) -> bool:
    """Check if an email address is valid."""
    pattern = r"^[\w\.-]+@[\w\.-]+\.\w+$"
    return re.match(pattern, email) is not None


# -----------------------------
# Clean & Normalize Text (for NLP)
# -----------------------------
def clean_text(text: str) -> str:
    """
    Normalize journal/post/voice text before sending to NLP.
    Removes extra spaces, newlines, & emojis.
    """
    # Remove emojis & symbols
    text = re.sub(r"[^\x00-\x7F]+", "", text)

    # Normalize whitespace
    text = " ".join(text.split())

    return text.strip()


# -----------------------------
# Username Generator
# -----------------------------
def generate_random_username() -> str:
    """
    Generates a random username with prefix 'user_'.
    """
    suffix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=6))
    return f"user_{suffix}"


# -----------------------------
# Timestamp Helper
# -----------------------------
def utc_timestamp() -> str:
    """Returns the current UTC timestamp (ISO-8601 format)."""
    return datetime.utcnow().isoformat()


# -----------------------------
# Standard API Response Wrapper
# -----------------------------
def success_response(message: str, data=None, status_code: int = 200):
    """
    Unified format for successful API responses.
    """
    return JSONResponse(
        status_code=status_code,
        content={
            "status": "success",
            "message": message,
            "data": data,
        },
    )


def error_response(message: str, status_code: int = 400):
    """
    Unified format for error responses.
    """
    return JSONResponse(
        status_code=status_code,
        content={
            "status": "error",
            "message": message,
        },
    )
