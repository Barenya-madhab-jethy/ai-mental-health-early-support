from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List
from ..db import get_db
from .. import models, schemas

router = APIRouter()

@router.get("/", response_model=List[schemas.ResourceOut])
def list_resources(db_session: Session = Depends(get_db)):
    # For demo: return static resources if table empty
    items = db_session.query(models.Resource).all()
    if not items:
        default = [
            models.Resource(title="How to manage stress", url="https://www.who.int/mental_health", category="Article", description="World Health Organization mental health basics"),
            models.Resource(title="Feeling Good: The New Mood Therapy", url="https://www.amazon.com/", category="Book", description="A classic CBT self-help book."),
        ]
        db_session.add_all(default)
        db_session.commit()
        items = db_session.query(models.Resource).all()
    return items
