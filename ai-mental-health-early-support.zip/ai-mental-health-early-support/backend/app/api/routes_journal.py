from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from .. import db, models, schemas
from ..db import get_db
from ..auth.jwt import get_current_user
from ..services.gemini_client import analyze_text

router = APIRouter()

@router.post("/", response_model=schemas.JournalOut)
def create_journal(payload: schemas.JournalCreate, db_session: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    entry = models.Journal(user_id=current_user.id, title=payload.title, content=payload.content)
    # analyze content asynchronously or inline
    try:
        analysis = analyze_text(payload.content)
        entry.analysis = analysis
    except Exception:
        entry.analysis = None

    db_session.add(entry)
    db_session.commit()
    db_session.refresh(entry)
    return entry

@router.get("/", response_model=List[schemas.JournalOut])
def list_journals(db_session: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    items = db_session.query(models.Journal).filter(models.Journal.user_id == current_user.id).all()
    return items
