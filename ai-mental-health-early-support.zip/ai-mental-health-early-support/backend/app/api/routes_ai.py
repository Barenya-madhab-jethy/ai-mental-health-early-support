from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from ..services.gemini_client import analyze_text
from ..auth.jwt import get_current_user

router = APIRouter()

class PromptRequest(BaseModel):
    prompt: str

@router.post("/ask")
def ask_ai(request: PromptRequest, user=Depends(get_current_user)):
    try:
        response = analyze_text(request.prompt)
        return {"response": response}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"AI service error: {str(e)}")
