from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from .. import db, models
from ..db import get_db
from ..auth.jwt import get_current_user
from ..services.gemini_client import analyze_text

router = APIRouter()

@router.post("/")
def create_post(payload: dict, db_session: Session = Depends(get_db), current_user = Depends(get_current_user)):
    content = payload.get("content")
    post = models.Post(user_id=current_user.id, content=content)
    try:
        post.analysis = analyze_text(content)
    except Exception:
        post.analysis = None
    db_session.add(post)
    db_session.commit()
    db_session.refresh(post)
    return {"ok": True, "post_id": post.id}

@router.get("/")
def list_posts(db_session: Session = Depends(get_db)):
    posts = db_session.query(models.Post).order_by(models.Post.created_at.desc()).limit(100).all()
    return posts
