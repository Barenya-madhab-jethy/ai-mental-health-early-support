import os
from fastapi import APIRouter, Depends, File, UploadFile, HTTPException
from sqlalchemy.orm import Session
from ..db import get_db
from .. import models
from ..auth.jwt import get_current_user
from ..config import VOICE_UPLOAD_DIR
from ..services.gemini_client import analyze_text

router = APIRouter()

os.makedirs(VOICE_UPLOAD_DIR, exist_ok=True)

@router.post("/")
async def upload_voice(file: UploadFile = File(...), db_session: Session = Depends(get_db), current_user = Depends(get_current_user)):
    # Save file
    filename = f"{current_user.id}_{int(__import__('time').time())}_{file.filename}"
    path = os.path.join(VOICE_UPLOAD_DIR, filename)
    try:
        with open(path, "wb") as f:
            content = await file.read()
            f.write(content)
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to save file")

    # Placeholder for transcription: In production, call a speech-to-text service.
    transcript = "[transcription unavailable in dev]"

    # Analyze transcript with Gemini (if we had real transcript)
    analysis = None
    try:
        analysis = analyze_text(transcript)
    except Exception:
        analysis = None

    voice = models.VoiceNote(user_id=current_user.id, file_path=path, transcript=transcript, analysis=analysis)
    db_session.add(voice)
    db_session.commit()
    db_session.refresh(voice)
    return {"ok": True, "voice_id": voice.id}
