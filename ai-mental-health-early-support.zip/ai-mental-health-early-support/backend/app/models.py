from sqlalchemy import Column, Integer, String, Boolean, Text, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from .db import Base

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(128), nullable=True)
    email = Column(String(256), unique=True, index=True, nullable=True)
    hashed_password = Column(String(256), nullable=True)
    is_anonymous = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    journals = relationship("Journal", back_populates="owner")
    posts = relationship("Post", back_populates="owner")
    voice_notes = relationship("VoiceNote", back_populates="owner")

class Journal(Base):
    __tablename__ = "journals"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"))
    title = Column(String(256), nullable=True)
    content = Column(Text, nullable=False)
    analysis = Column(Text, nullable=True)  # json string
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    owner = relationship("User", back_populates="journals")

class Post(Base):
    __tablename__ = "posts"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"))
    content = Column(Text, nullable=False)
    analysis = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    owner = relationship("User", back_populates="posts")

class VoiceNote(Base):
    __tablename__ = "voice_notes"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"))
    file_path = Column(String(512))
    transcript = Column(Text, nullable=True)
    analysis = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    owner = relationship("User", back_populates="voice_notes")

class Resource(Base):
    __tablename__ = "resources"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(256))
    url = Column(String(1024))
    category = Column(String(128))
    description = Column(Text)
