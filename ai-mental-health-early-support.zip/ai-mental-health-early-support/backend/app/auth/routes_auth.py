from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from passlib.context import CryptContext
from .. import db, models, schemas
from ..auth.jwt import create_access_token, get_current_user
from ..db import get_db

router = APIRouter()
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

@router.post("/signup", response_model=schemas.UserOut)
def signup(user_in: schemas.UserCreate, db_session: Session = Depends(get_db)):
    if user_in.email:
        existing = db_session.query(models.User).filter(models.User.email == user_in.email).first()
        if existing:
            raise HTTPException(status_code=400, detail="Email already registered")
    user = models.User(
        name=user_in.name,
        email=user_in.email,
        is_anonymous=user_in.is_anonymous
    )
    if user_in.password:
        user.hashed_password = pwd_context.hash(user_in.password)
    db_session.add(user)
    db_session.commit()
    db_session.refresh(user)
    return user

@router.post("/login")
def login(form_data: dict, db_session: Session = Depends(get_db)):
    # Expects JSON: { "email": "...", "password": "..." }
    email = form_data.get("email")
    password = form_data.get("password")
    user = db_session.query(models.User).filter(models.User.email == email).first()
    if not user or not user.hashed_password:
        raise HTTPException(status_code=400, detail="Incorrect credentials")
    if not pwd_context.verify(password, user.hashed_password):
        raise HTTPException(status_code=400, detail="Incorrect credentials")

    token = create_access_token({"user_id": user.id, "email": user.email})
    return {"access_token": token, "token_type": "bearer"}

@router.post("/anonymous")
def create_anonymous(db_session: Session = Depends(get_db)):
    user = models.User(is_anonymous=True)
    db_session.add(user)
    db_session.commit()
    db_session.refresh(user)
    token = create_access_token({"user_id": user.id})
    return {"access_token": token, "token_type": "bearer"}

@router.get("/me", response_model=schemas.UserOut)
def me(current_user: models.User = Depends(get_current_user)):
    return current_user
