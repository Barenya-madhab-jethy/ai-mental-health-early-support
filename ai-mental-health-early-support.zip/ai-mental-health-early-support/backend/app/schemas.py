from pydantic import BaseModel, EmailStr
from typing import Optional, List
from datetime import datetime

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"

class TokenData(BaseModel):
    email: Optional[str] = None
    user_id: Optional[int] = None

class UserCreate(BaseModel):
    name: Optional[str]
    email: Optional[EmailStr]
    password: Optional[str]
    is_anonymous: Optional[bool] = False

class UserOut(BaseModel):
    id: int
    name: Optional[str]
    email: Optional[EmailStr]
    is_anonymous: bool
    created_at: datetime

    class Config:
        from_attributes = True

class JournalCreate(BaseModel):
    title: Optional[str]
    content: str

class JournalOut(BaseModel):
    id: int
    title: Optional[str]
    content: str
    analysis: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True

class ResourceOut(BaseModel):
    id: int
    title: str
    url: str
    category: Optional[str]
    description: Optional[str]

    class Config:
        from_attributes = True
